import { describe, it, expect } from "vitest";
import { analyzeMessage, EXAMPLES } from "./analyzer";

describe("analyzer examples", () => {
  it("A is suspicious or potentially suspicious with fee/urgency/guarantee", () => {
    const a = analyzeMessage(EXAMPLES.A.text);
    expect(a.classification).not.toBe("No Obvious Warning Signs");
    const ids = a.signals.map((s) => s.id);
    expect(ids).toEqual(expect.arrayContaining(["fee", "urgency", "guarantee"]));
  });
  it("B has no obvious warning signs", () => {
    expect(analyzeMessage(EXAMPLES.B.text).classification).toBe("No Obvious Warning Signs");
  });
  it("C is high risk with OTP request", () => {
    const a = analyzeMessage(EXAMPLES.C.text);
    expect(a.risk).toBe("High");
    expect(a.signals.map((s) => s.id)).toContain("credentials");
  });
  it("D is not high risk but includes a verification note", () => {
    const a = analyzeMessage(EXAMPLES.D.text);
    expect(a.risk).not.toBe("High");
    expect(a.notes.join(" ")).toMatch(/official/);
  });
});
