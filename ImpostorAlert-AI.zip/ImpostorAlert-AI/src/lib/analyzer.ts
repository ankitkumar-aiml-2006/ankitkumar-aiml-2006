// Transparent rule-based demo analyzer. Runs entirely in the browser.
export type RiskLevel = "Low" | "Medium" | "High";
export type Classification = "Suspicious" | "Potentially Suspicious" | "No Obvious Warning Signs";

export interface Signal {
  id: string;
  label: string;
  weight: number;
  excerpts: string[];
  why: string;
}

export interface Analysis {
  classification: Classification;
  risk: RiskLevel;
  score: number;
  signals: Signal[];
  notes: string[];
  steps: string[];
}

interface Rule {
  id: string;
  label: string;
  weight: number;
  patterns: RegExp[];
  why: string;
}

const RULES: Rule[] = [
  {
    id: "fee",
    label: "Upfront fee or payment request",
    weight: 3,
    patterns: [
      /\b(registration|processing|application|security|joining|verification|training)\s+(fee|charges?|deposit|amount)\b/gi,
      /\bpay\s+(?:a\s+|the\s+)?(?:₹|rs\.?|inr|\$)?\s?[\d,]*\s?(?:fee|amount|now|immediately|today)?/gi,
      /(?:₹|rs\.?\s?|inr\s?)\d[\d,]*/gi,
    ],
    why: "Genuine employers and scholarship bodies rarely ask applicants to pay to be selected. Upfront payment is a common sign of fraud.",
  },
  {
    id: "urgency",
    label: "Pressure or urgency",
    weight: 2,
    patterns: [
      /\b(immediately|urgent(?:ly)?|right now|within \d+\s?(?:hours?|hrs?|minutes?)|today only|last chance|act now|expires? (?:today|soon)|asap)\b/gi,
    ],
    why: "Urgency pushes you to act before you can check. Legitimate processes usually give reasonable time.",
  },
  {
    id: "threat",
    label: "Threats or account-blocking language",
    weight: 2,
    patterns: [/\b(account (?:will be )?(?:blocked|suspended|closed)|legal action|penalty|will be cancelled|arrest)\b/gi],
    why: "Threats create fear so you comply quickly. Verify independently before reacting.",
  },
  {
    id: "guarantee",
    label: "Guaranteed or pre-selected outcome",
    weight: 2,
    patterns: [/\b(guaranteed|100% (?:placement|selection|job)|pre-?selected|secure your (?:slot|seat|internship|job)|you have won)\b/gi],
    why: "Real selection processes rarely guarantee results, especially when you did not apply.",
  },
  {
    id: "credentials",
    label: "Request for OTP, password, PIN or banking details",
    weight: 4,
    patterns: [
      /\b(share|send|tell|provide|give|enter|confirm)\b[^.!?\n]{0,30}\b(otp|password|pin|cvv|upi pin|card number|bank details|net ?banking)\b/gi,
      /\b(otp|cvv|upi pin)\b/gi,
    ],
    why: "No genuine organisation needs your OTP, password, PIN or CVV. Sharing them can give full access to your accounts.",
  },
  {
    id: "shortlink",
    label: "Shortened or suspicious link",
    weight: 2,
    patterns: [
      /\b(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl|is\.gd|cutt\.ly|rb\.gy|shorturl\.at)\/\S*/gi,
      /https?:\/\/\d{1,3}(?:\.\d{1,3}){3}\S*/gi,
      /https?:\/\/\S+\.(?:xyz|top|click|info|buzz|live)\b\S*/gi,
    ],
    why: "Short or unusual links hide the real destination. Type the official address yourself instead.",
  },
  {
    id: "pii",
    label: "Request for sensitive personal documents",
    weight: 2,
    patterns: [/\b(aadhaar|aadhar|pan card|passport number|bank account number|date of birth)\b/gi],
    why: "Identity documents can be misused. Only share them through verified official portals.",
  },
];

const OFFICIAL_CONTEXT = /\b(official (?:website|account|portal)|log ?in to your official)\b/i;
const LINK = /https?:\/\/\S+|www\.\S+/i;

export function analyzeMessage(text: string): Analysis {
  const signals: Signal[] = [];
  for (const r of RULES) {
    const found = new Set<string>();
    for (const p of r.patterns) {
      for (const m of text.matchAll(p)) {
        const s = m[0].trim();
        if (s.length > 1) found.add(s);
      }
    }
    if (found.size) {
      signals.push({ id: r.id, label: r.label, weight: r.weight, excerpts: [...found].slice(0, 3), why: r.why });
    }
  }

  let score = signals.reduce((a, s) => a + s.weight, 0);
  // Combination bonus: fee + urgency/guarantee is a classic scam shape.
  const has = (id: string) => signals.some((s) => s.id === id);
  if (has("fee") && (has("urgency") || has("guarantee"))) score += 1;

  const risk: RiskLevel = score >= 5 ? "High" : score >= 2 ? "Medium" : "Low";
  const classification: Classification =
    risk === "High" ? "Suspicious" : risk === "Medium" ? "Potentially Suspicious" : "No Obvious Warning Signs";

  const notes: string[] = [];
  if (!signals.length) notes.push("None of the listed warning patterns were found in this text. This does not confirm the sender is genuine.");
  if (OFFICIAL_CONTEXT.test(text)) notes.push("The message refers to an 'official' website or account. Find that site yourself rather than trusting links or names in the message.");
  if (LINK.test(text) && !has("shortlink")) notes.push("The message contains a link. Check the domain carefully before opening it.");
  if (signals.length === 1 && risk !== "High") notes.push("Only one weak signal was found, so this result is uncertain. Context matters.");

  const steps = [
    "Verify the sender through an independently located official website or phone number.",
    "Check the sender's email address and domain carefully.",
  ];
  if (has("fee")) steps.push("Do not pay any fee until the organisation is independently verified.");
  if (has("credentials")) steps.push("Do not share the OTP, password or PIN. Report the message to your bank or the service provider.");
  if (has("shortlink")) steps.push("Do not tap the link. Type the official address manually.");
  steps.push("Report suspicious messages to the relevant service or authority.");

  return { classification, risk, score, signals, notes, steps };
}

export function summarize(a: Analysis): string {
  return [
    "ImpostorAlert AI — Rule-Based Demo Analysis",
    `Classification: ${a.classification}`,
    `Risk level: ${a.risk}`,
    `Warning signs: ${a.signals.length ? a.signals.map((s) => s.label).join("; ") : "none of the listed patterns"}`,
    "Next steps:",
    ...a.steps.map((s) => `- ${s}`),
    "Never share OTPs, passwords, PINs or banking credentials.",
    "This is an initial screening tool, not a guarantee. Verify the sender independently.",
  ].join("\n");
}

export const EXAMPLES = {
  A: { title: "Example A — Internship fee", text: "Congratulations! Pay a registration fee immediately to secure your guaranteed internship." },
  B: { title: "Example B — Ordinary reply", text: "Thank you for applying. Our recruitment team will contact shortlisted candidates by email." },
  C: { title: "Example C — Scholarship + OTP", text: "Congratulations! You have been pre-selected for a scholarship. Pay ₹2,000 immediately to secure your slot. Share your OTP to verify your account." },
  D: { title: "Example D — Legitimate-looking", text: "Congratulations! You have been selected for the Tech Scholars Program. Please log in to your official account to complete your application and upload documents. For queries, contact us through our official website." },
} as const;
export type ExampleKey = keyof typeof EXAMPLES;
