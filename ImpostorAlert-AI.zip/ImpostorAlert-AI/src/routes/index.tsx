import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { analyzeMessage, summarize, EXAMPLES, type Analysis, type ExampleKey } from "@/lib/analyzer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ImpostorAlert AI — Detect the Impostor. Protect Your Future." },
      { name: "description", content: "Screen suspicious job, internship and scholarship messages for warning signs. Built by Team AETHRIX for Techno Utsav 5.0." },
      { property: "og:title", content: "ImpostorAlert AI — Scam message screening" },
      { property: "og:description", content: "Paste a message, see warning signs, and learn how to verify opportunities safely." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const NAV = [
  ["analyzer", "Analyzer"], ["checklist", "Checklist"], ["examples", "Examples"], ["how", "How it works"],
  ["tech", "Tech"], ["roadmap", "Roadmap"], ["team", "Team"], ["faq", "FAQ"],
] as const;

function Logo() {
  return (
    <svg viewBox="0 0 32 32" className="h-8 w-8" aria-hidden>
      <defs><linearGradient id="lg" x1="0" x2="1"><stop offset="0" stopColor="var(--primary)" /><stop offset="1" stopColor="var(--violet)" /></linearGradient></defs>
      <path d="M16 2 28 7v8c0 7.5-5 12.5-12 15C9 27.5 4 22.5 4 15V7z" fill="none" stroke="url(#lg)" strokeWidth="2.2" />
      <path d="M16 10v7" stroke="var(--primary)" strokeWidth="2.6" strokeLinecap="round" /><circle cx="16" cy="21.5" r="1.6" fill="var(--primary)" />
    </svg>
  );
}

const btn = "inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50";
const btnPrimary = `${btn} bg-gradient-brand text-primary-foreground shadow-glow hover:brightness-110`;
const btnGhost = `${btn} border border-input bg-secondary/60 text-foreground hover:bg-accent`;

function Section({ id, eyebrow, title, children }: { id: string; eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-6xl px-4 py-20">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary">{eyebrow}</p>
      <h2 className="mt-2 text-3xl font-bold md:text-4xl">{title}</h2>
      <div className="mt-10">{children}</div>
    </section>
  );
}

function Index() {
  const [menu, setMenu] = useState(false);
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Analysis | null>(null);
  const [copied, setCopied] = useState(false);

  const load = (k: ExampleKey) => { setText(EXAMPLES[k].text); setError(""); setResult(null); document.getElementById("analyzer")?.scrollIntoView(); };
  const clear = () => { setText(""); setError(""); setResult(null); };
  const run = () => {
    if (!text.trim()) { setError("Please paste or type a message to analyze."); return; }
    if (text.trim().length < 10) { setError("That message is very short. Add the full text for a better assessment."); return; }
    setError(""); setLoading(true); setResult(null);
    setTimeout(() => { setResult(analyzeMessage(text)); setLoading(false); setTimeout(() => document.getElementById("result")?.scrollIntoView({ block: "start" }), 50); }, 600);
  };
  const copy = async () => {
    if (!result) return;
    try { await navigator.clipboard.writeText(summarize(result)); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { setError("Copy failed. Your browser blocked clipboard access."); }
  };

  const riskColor = result?.risk === "High" ? "text-destructive" : result?.risk === "Medium" ? "text-warning" : "text-success";
  const riskBg = result?.risk === "High" ? "bg-destructive" : result?.risk === "Medium" ? "bg-warning" : "bg-success";
  const riskPct = result?.risk === "High" ? 100 : result?.risk === "Medium" ? 60 : 22;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#top" className="flex items-center gap-2 font-bold"><Logo /> ImpostorAlert <span className="text-gradient">AI</span></a>
          <nav className="hidden gap-5 text-sm text-muted-foreground lg:flex">
            {NAV.map(([id, l]) => <a key={id} href={`#${id}`} className="hover:text-primary">{l}</a>)}
          </nav>
          <button className={`${btnGhost} px-3 py-2 lg:hidden`} aria-expanded={menu} aria-label="Toggle menu" onClick={() => setMenu(!menu)}>{menu ? "Close" : "Menu"}</button>
        </div>
        {menu && (
          <nav className="grid gap-1 border-t border-border px-4 py-3 lg:hidden">
            {NAV.map(([id, l]) => <a key={id} href={`#${id}`} onClick={() => setMenu(false)} className="rounded-md px-2 py-2 hover:bg-accent">{l}</a>)}
          </nav>
        )}
      </header>

      <main id="top">
        {/* HERO */}
        <section className="mx-auto max-w-6xl px-4 pb-16 pt-20 text-center md:pt-28">
          <p className="mx-auto inline-block rounded-full border border-border px-4 py-1 font-mono text-xs text-muted-foreground">Hack X: Among Us · Techno Utsav 5.0 · ADGIPS, New Delhi</p>
          <h1 className="mt-6 text-5xl font-bold tracking-tight md:text-7xl">ImpostorAlert <span className="text-gradient">AI</span></h1>
          <p className="mt-4 text-xl font-medium md:text-2xl">Detect the Impostor. Protect Your Future.</p>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">An intelligent guardrail that detects risky messages and helps you act with confidence.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a href="#analyzer" className={btnPrimary}>Analyze a Message</a>
            <a href="#how" className={btnGhost}>Explore How It Works</a>
          </div>
          <div className="glass mx-auto mt-14 max-w-3xl p-6 text-left">
            <h3 className="font-semibold">The problem</h3>
            <p className="mt-2 text-sm text-muted-foreground">Students and job seekers receive deceptive scholarship, internship, job and "account verification" messages that ask for fees, OTPs or personal details. These messages imitate real organisations and rely on pressure and excitement.</p>
          </div>
          <div className="mx-auto mt-8 grid max-w-4xl grid-cols-2 gap-3 md:grid-cols-4">
            {["INPUT", "ANALYSE", "ASSESS", "PROTECT"].map((s, i) => (
              <div key={s} className="glass p-4"><p className="font-mono text-xs text-primary">0{i + 1}</p><p className="mt-1 font-bold tracking-wider">{s}</p></div>
            ))}
          </div>
        </section>

        {/* ANALYZER */}
        <Section id="analyzer" eyebrow="Live analyzer" title="Check a message">
          <div className="glass p-5 md:p-7">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <label htmlFor="msg" className="text-sm font-medium">Paste an SMS, email, WhatsApp, job, internship or scholarship message</label>
              <select aria-label="Load an example" className="rounded-lg border border-input bg-secondary px-3 py-2 text-sm" value="" onChange={(e) => e.target.value && load(e.target.value as ExampleKey)}>
                <option value="">Choose a sample…</option>
                <option value="A">Suspicious sample</option>
                <option value="B">Ordinary sample</option>
                <option value="C">Scholarship + OTP sample</option>
                <option value="D">Legitimate-looking sample</option>
              </select>
            </div>
            <textarea id="msg" value={text} onChange={(e) => setText(e.target.value)} rows={7} placeholder="Paste the message text here…"
              className="mt-3 w-full rounded-lg border border-input bg-background/60 p-4 font-mono text-sm outline-none focus:ring-2 focus:ring-ring" />
            {error && <p role="alert" className="mt-2 text-sm text-destructive">{error}</p>}
            <div className="mt-4 flex flex-wrap gap-3">
              <button className={btnPrimary} onClick={run} disabled={loading}>{loading ? "Analyzing…" : "Analyze Message"}</button>
              <button className={btnGhost} onClick={() => load("A")}>Load Example</button>
              <button className={btnGhost} onClick={clear}>Clear</button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">Analysis runs in your browser. Your message is not sent anywhere or saved. This is an initial screening tool, not a guarantee. Verify the sender independently.</p>
          </div>

          {loading && <div className="glass mt-6 animate-pulse p-6 text-center text-muted-foreground">Scanning for warning signs…</div>}

          {!result && !loading && <p className="mt-6 text-center text-sm text-muted-foreground">Results will appear here after you analyze a message.</p>}

          {result && (
            <div id="result" className="glass mt-6 p-5 md:p-7 animate-in fade-in slide-in-from-bottom-2">
              <div className="flex flex-wrap items-center gap-3">
                <span className={`rounded-full border border-current px-3 py-1 text-sm font-semibold ${riskColor}`}>{result.classification}</span>
                <span className="rounded-full bg-secondary px-3 py-1 font-mono text-xs">Rule-Based Demo Analysis</span>
                <span className="rounded-full bg-secondary px-3 py-1 font-mono text-xs text-muted-foreground">Trained ML Model: not used</span>
              </div>
              <div className="mt-5">
                <div className="flex justify-between text-sm"><span>Risk level</span><span className={`font-bold ${riskColor}`}>{result.risk}</span></div>
                <div className="mt-2 h-3 overflow-hidden rounded-full bg-muted"><div className={`h-full ${riskBg} transition-all duration-700`} style={{ width: `${riskPct}%` }} /></div>
                <div className="mt-1 flex justify-between font-mono text-[10px] text-muted-foreground"><span>LOW</span><span>MEDIUM</span><span>HIGH</span></div>
              </div>

              <h3 className="mt-6 font-semibold">Warning signs found ({result.signals.length})</h3>
              {result.signals.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">No listed warning patterns detected.</p> : (
                <ul className="mt-3 grid gap-3 md:grid-cols-2">
                  {result.signals.map((s) => (
                    <li key={s.id} className="rounded-lg border border-border bg-background/40 p-4">
                      <p className="font-medium">{s.label}</p>
                      <div className="mt-2 flex flex-wrap gap-2">{s.excerpts.map((e) => <code key={e} className="rounded bg-destructive/15 px-2 py-0.5 text-xs text-destructive">"{e}"</code>)}</div>
                      <p className="mt-2 text-sm text-muted-foreground">{s.why}</p>
                    </li>
                  ))}
                </ul>
              )}
              {result.notes.length > 0 && <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-muted-foreground">{result.notes.map((n) => <li key={n}>{n}</li>)}</ul>}

              <h3 className="mt-6 font-semibold">Recommended next steps</h3>
              <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm">{result.steps.map((s) => <li key={s}>{s}</li>)}</ol>

              <div className="mt-6 rounded-lg border border-destructive/50 bg-destructive/10 p-4 text-sm font-medium">Never share OTPs, passwords, PINs or banking credentials with anyone.</div>
              <p className="mt-3 text-xs text-muted-foreground">Demo assessment based on transparent rules. This is an initial screening tool, not a guarantee. Verify the sender independently.</p>
              <div className="mt-5 flex flex-wrap gap-3">
                <button className={btnPrimary} onClick={() => { clear(); document.getElementById("msg")?.focus(); }}>Analyze Another Message</button>
                <button className={btnGhost} onClick={copy}>{copied ? "Copied!" : "Copy Summary"}</button>
              </div>
            </div>
          )}
        </Section>

        <Section id="checklist" eyebrow="Stay safe" title="Safety checklist">
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {["Verify the sender through an independently located official website or contact channel.", "Inspect the sender address and domain carefully.", "Be cautious about upfront registration or processing fees.", "Never share OTPs, passwords, PINs, or banking credentials.", "Avoid clicking suspicious links.", "Do not download unexpected attachments.", "Contact the institution using independently verified contact details.", "Report suspicious communications to the relevant service or authority.", "Do not make decisions solely on this tool's result."].map((c) => (
              <li key={c} className="glass flex gap-3 p-4 text-sm"><span className="text-primary">✓</span>{c}</li>
            ))}
          </ul>
        </Section>

        <Section id="examples" eyebrow="Example lab" title="Try the demo messages">
          <div className="grid gap-4 md:grid-cols-2">
            {(Object.keys(EXAMPLES) as ExampleKey[]).map((k) => (
              <div key={k} className="glass flex flex-col p-5">
                <p className="font-semibold">{EXAMPLES[k].title}</p>
                <p className="mt-2 flex-1 font-mono text-sm text-muted-foreground">"{EXAMPLES[k].text}"</p>
                <button className={`${btnGhost} mt-4 self-start`} onClick={() => load(k)}>Load into analyzer</button>
              </div>
            ))}
          </div>
        </Section>

        <Section id="how" eyebrow="How it works" title="From message to guidance">
          <div className="grid gap-3 md:grid-cols-7">
            {[["Input", "User supplies message text."], ["Preprocessing", "Normalize and clean text."], ["Features", "TF-IDF vectorization."], ["Classification", "Logistic Regression baseline."], ["Assessment", "Identify warning signs."], ["Output", "Explain and recommend."], ["Improvement", "Evaluate precision, recall, F1."]].map(([t, d], i) => (
              <div key={t} className="glass p-4"><p className="font-mono text-xs text-primary">0{i + 1}</p><p className="mt-1 font-semibold">{t}</p><p className="mt-1 text-xs text-muted-foreground">{d}</p></div>
            ))}
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="glass border-l-4 border-l-success p-5"><p className="font-semibold text-success">Implemented now</p><p className="mt-2 text-sm text-muted-foreground">A working, transparent rule-based analyzer that runs in the browser, highlights matched phrases, and explains each warning sign.</p></div>
            <div className="glass border-l-4 border-l-violet p-5"><p className="font-semibold text-violet">Planned</p><p className="mt-2 text-sm text-muted-foreground">TF-IDF + Logistic Regression model. No labelled dataset has been used and no model has been trained yet, so no accuracy figures are claimed.</p></div>
          </div>
        </Section>

        <Section id="tech" eyebrow="Technical architecture" title="What it's built with">
          <div className="glass overflow-x-auto p-5">
            <div className="flex min-w-max items-center gap-2 font-mono text-xs md:text-sm">
              {["Message Input", "Preprocessing", "Feature Extraction / Rule Checks", "Classification", "Warning Signs", "Safety Guidance"].map((s, i, a) => (
                <span key={s} className="flex items-center gap-2"><span className="rounded-md border border-primary/40 bg-primary/10 px-3 py-2">{s}</span>{i < a.length - 1 && <span className="text-primary">→</span>}</span>
              ))}
            </div>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[["Python", "Core language for the planned model."], ["Pandas", "Data handling and cleaning."], ["scikit-learn", "Planned ML model library."], ["TF-IDF", "Turns text into weighted features."], ["Logistic Regression", "Simple, explainable baseline classifier."], ["Streamlit", "Python web interface option."], ["VS Code", "Development environment."], ["This demo", "React + TypeScript, rule-based in browser."]].map(([t, d]) => (
              <div key={t} className="glass p-4"><p className="font-semibold">{t}</p><p className="mt-1 text-sm text-muted-foreground">{d}</p></div>
            ))}
          </div>
          <p className="mt-6 text-sm text-muted-foreground">Model quality will depend on data quality and a strict train/test separation. Evaluation will use precision, recall and F1-score. Both false positives (safe messages flagged) and false negatives (scams missed) remain possible.</p>
        </Section>

        <Section id="impact" eyebrow="Feasibility & responsible AI" title="Honest about what it can do">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="glass p-5"><p className="font-semibold">Feasibility & impact</p><ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground"><li>Open-source tools that run on student laptops.</li><li>Helps students recognise suspicious patterns early.</li><li>Encourages independent verification and safer data handling.</li></ul></div>
            <div className="glass p-5"><p className="font-semibold">Limitations</p><ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground"><li>Text alone cannot verify a sender's real identity.</li><li>False positives and false negatives are possible.</li><li>Dataset quality affects future model performance.</li><li>Supports human decisions; does not replace checks.</li></ul></div>
          </div>
        </Section>

        <Section id="roadmap" eyebrow="Future roadmap" title="Planned improvements">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {["Evaluation on public datasets", "Multilingual support", "URL reputation checks via a reliable service", "Better model robustness", "Improved classification and evaluation", "Privacy-preserving analysis"].map((r) => (
              <div key={r} className="glass flex items-center justify-between gap-3 p-4 text-sm"><span>{r}</span><span className="rounded-full bg-violet/20 px-2 py-0.5 font-mono text-[10px] text-violet">PLANNED</span></div>
            ))}
          </div>
        </Section>

        <Section id="team" eyebrow="About" title="Team AETHRIX">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {([["Ankit Kumar", "Team Leader"], ["Mayank Sharma", "Team Member"], ["Ankita Pal", "Team Member"], ["Anshul Pundir", "Team Member"]] as const).map(([n, r]) => (
              <div key={n} className="glass p-5 text-center">
                <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-gradient-brand text-lg font-bold text-primary-foreground">{n.split(" ").map((p) => p[0]).join("")}</div>
                <p className="mt-3 font-semibold">{n}</p><p className="text-sm text-muted-foreground">{r}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 text-center text-sm text-muted-foreground">ImpostorAlert AI · Hack X: Among Us — Techno Utsav 5.0 · ADGIPS, New Delhi · Detect the Impostor. Protect Your Future. <span className="text-primary">Built for safer opportunities.</span></p>
        </Section>

        <Section id="faq" eyebrow="FAQ" title="Common questions">
          <div className="space-y-3">
            {FAQ.map(([q, a]) => (
              <details key={q} className="glass group p-5">
                <summary className="flex cursor-pointer list-none items-center justify-between font-medium">{q}<span className="text-primary transition group-open:rotate-45">+</span></summary>
                <p className="mt-3 text-sm text-muted-foreground">{a}</p>
              </details>
            ))}
          </div>
        </Section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div><p className="flex items-center gap-2 font-bold"><Logo /> ImpostorAlert AI</p><p className="mt-2 text-sm text-muted-foreground">Detect the Impostor. Protect Your Future.</p><p className="mt-1 text-xs text-muted-foreground">Hack X: Among Us — Techno Utsav 5.0 · ADGIPS, New Delhi · Team AETHRIX</p></div>
            <nav className="flex flex-wrap gap-4 text-sm text-muted-foreground">{NAV.map(([id, l]) => <a key={id} href={`#${id}`} className="hover:text-primary">{l}</a>)}</nav>
          </div>
          <p className="mt-8 text-xs text-muted-foreground">Responsible use: ImpostorAlert AI is an initial screening tool for awareness. It does not verify identities or guarantee safety. Always verify senders independently and never share OTPs, passwords, PINs or banking credentials.</p>
        </div>
      </footer>
    </div>
  );
}

const FAQ: [string, string][] = [
  ["What is ImpostorAlert AI?", "A screening tool that highlights common warning signs in job, internship, scholarship and account messages, and suggests how to verify them."],
  ["How does message analysis work?", "This demo uses transparent rules that look for patterns like upfront fees, urgency, guaranteed outcomes, OTP requests and short links, then combines them into a Low, Medium or High risk level."],
  ["Can it detect every scam?", "No. Scammers change wording constantly, and some scams contain no obvious warning signs."],
  ["Does a low-risk result mean the message is safe?", "No. It only means none of the listed patterns were found. Always verify the sender."],
  ["Does the tool verify the sender's identity?", "No. Text alone cannot prove who sent a message."],
  ["What should I do if a message asks for an OTP?", "Do not share it. No genuine organisation needs your OTP. Contact the service using details you found yourself."],
  ["Does it store submitted messages?", "No. Analysis happens in your browser and the message is not sent or saved."],
  ["Is the ML model fully trained and validated?", "No. The TF-IDF + Logistic Regression model is a planned step. The current demo is rule-based."],
  ["Can it analyze job, internship, and scholarship messages?", "Yes, those are its main focus, along with account-verification messages."],
  ["What are its limitations?", "False positives and negatives, English-only rules, no link reputation checks, and no sender verification."],
];
